package seleniumStag;
import java.util.regex.Pattern;
import java.io.File;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import org.openqa.selenium.*;

import org.openqa.selenium.Proxy.ProxyType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
//import org.openqa.selenium.firefox.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.io.Files;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.interactions.*;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

public class prestashopTest {
	private static String baseUrl;
	private WebDriver driver;  
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();
	private HashMap<String, Object> vars;
	  JavascriptExecutor js;
	//  private Util monUtil;
	final static Logger logger = Logger.getLogger(seleniumStag.prestashopTest.class);
	@BeforeEach
	public void setUp() throws Exception {
		driver = new ChromeDriver(new ChromeOptions().addArguments("--disable-search-engine-choice-screen"));
		baseUrl = "http://www.qualifiez.fr/monPrestashop2/prestashop/index.php";
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(60));
		driver.get(baseUrl);
		js = (JavascriptExecutor) driver;
        // commandes pour lancer un profile firefox spécifique
//		FirefoxOptions options = new FirefoxOptions();
//		FirefoxProfile monProfil = new FirefoxProfile(new File("/Users/dominiquemereaux/Library/Application Support/Firefox/Profiles/rfqfjl41.monProfil"));
//		options.setProfile(monProfil);
		//	driver = new FirefoxDriver(options);
//		DesiredCapabilities capabilities = new DesiredCapabilities().edge();
//		driver = new RemoteWebDriver(new URL("http://192.168.1.34:4444/wd/hu//b"),capabilities);
		

	}
	public String waitForWindow(int timeout) {
		try {
			Thread.sleep(timeout);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		Set<String> whNow = driver.getWindowHandles();
		Set<String> whThen = (Set<String>) vars.get("window_handles");
		if (whNow.size() > whThen.size()) {
			whNow.removeAll(whThen);
		}
		return whNow.iterator().next();
	}
	//logger et assertion
	@Test 
	public void faireDesLogsEtDesAssertions()
	{
		// Utiliser le logger avec les différents niveaux de log
		// python :
	    //logging.debug("running test_3_1")
	    //assert time.localtime().tm_hour  >  23
		// faire une assertion avec assertEqual
		// modifier le niveau de log
		logger.info("toto");
		js.executeScript("$(window.open(''))");

	}
	//vérifier que l'on est sur la bonne page puis récupérer les handles
	@Test 
	public void verifierLaDocEnLignePython()
	{   // faire l'équivalent en java
		// driver.get("https://www.python.org/")
		// logging.info("URL" + driver.current_url)
	    // assert driver.title=="Welcome to Python.org"
		// récupérer les Handles: driver.window_handles
		// Afficher en mode info
	}
	//tester la frame apres avoir accepter la modale, puis revenir à la page principale
	@Test 
	public void testLaFrame() throws InterruptedException, IOException {
		//driver.get("https://www.w3schools.com/jsref/tryit.asp?filename=tryjsref_alert")
	    //driver.maximize_window()
	    //driver.find_element_by_id("accept-choices").click()
	    //frame = driver.find_element_by_id("iframeResult")
		//driver.switch_to.frame(frame)
		//driver.switch_to.default_content()
		driver.get("https://www.w3schools.com/jsref/tryit.asp?filename=tryjsref_alert");
		driver.findElement(By.id("accept-choices"));
	}
	//tester la frame apres avoir accepter la modale, puis revenir à la page principale
	@Test 
	public void testLaFrameCaptureEcran() throws InterruptedException, IOException {
		//driver.get("https://www.w3schools.com/jsref/tryit.asp?filename=tryjsref_alert")
	    //driver.maximize_window()
	    //driver.find_element_by_id("accept-choices").click()
		// driver.get_screenshot_as_file(screenshot_name)
	    //frame = driver.find_element_by_id("iframeResult")
		//driver.switch_to.frame(frame)
		//driver.switch_to.default_content()
		// en java
		//File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	    //File des1 = new File("titi.png");
	    //Files.copy(scrFile, des1);
	}
	// Utilisation des fonctions de base 
	@Test 
	public void chercherLeMug() throws InterruptedException, MalformedURLException {
		// chercher le lien contact:
		// elt = driver.find_element_by_id("link-static-page-contact-2")
		// driver.find_element_by_link_text('Contactez-nous')
		// chercher le webElement champ de recherche avec name, puis xpath, puis css
		// driver.find_element_by_xpath('//*[@id="search_widget"]/form/input[2]')
		// récupérer un texte entre 2 balises lien contactez-nous:     element=driver.find_element_by_css_selector("#_desktop_user_info > div > a > span")
	    //print("Element Text:" + element.text)
		// Notez pas d'équivalent du get_property
		//récupérer l'atribut placeholder du champ de recherche
		//element=driver.find_element_by_css_selector("#_desktop_user_info > div > a > span")
	    //element_outerHTML = element.get_attribute("outerHTML")
		// vérifier que le champ de recherche est bien affiché
		//driver.navigate().back();
		assertEquals(driver.findElement(By.name("s")).getAttribute("placeholder"),"Rechercher");
		assertTrue(driver.findElement(By.name("s")).isDisplayed());

	}
	// checker la Box et vérifier qu'elle est checkée
	//    element = driver.find_element_by_xpath("//*[@id='_desktop_user_info']/div/a")
	//    element.click()
    //    element.is_checked()

	@Test 
	public void checkerLaBOX() throws InterruptedException {
		driver.get("http://www.qualifiez.fr/monPrestashop2/prestashop/index.php?id_product=1&id_product_attribute=3&rewrite=hummingbird-printed-t-shirt&controller=product#/2-taille-m/8-couleur-blanc");
	}
	@Test
//    driver.find_element_by_xpath(dropdown).click()
//    liste_option =driver.find_elements_by_xpath(dropdown+'/'+'option')
//    for option in liste_option :
//        if option.text == value :
//            option.click()
//    faire un code similaire qui permettra de sélectionner la taille M
//    URL: http://www.qualifiez.fr/monPrestashop2/prestashop/index.php?id_product=1&id_product_attribute=1&rewrite=hummingbird-printed-t-shirt&controller=product#/1-taille-s/8-couleur-blanc
// comme en python il existe un object select: Select select = new Select(driver.findElement(By.id("group_1")));

	public void dropdownList()
	{
	}
	// sélectionner un élément, cliquez sur une fenêtre modale , cliquez sur le bouton commander
	// verifier le titre de la page : panier.
	@Test
	public void gererLesModales()
	{
		
	
	}
//    aller sur le site: https://www.w3schools.com/jsref/tryit.asp?filename=tryjsref_alert
//    N'oubliez d'accepter la modale
//    try_it_button = driver.find_element_by_css_selector('[onclick*="myFunction()"]')
//    try_it_button.click()
//    alert = driver.switch_to.alert
//    assert "Hello!" in alert.text, "Incorrect text"
//    alert.dismiss()
//    driver.quit()
	@Test
	public void gererLesAlertes()
	{
	
	}

	// compter les fenêtres
	@Test
	public void compterLesFenetres() {

		driver.get("http://www.qualifiez.fr/examples/Selenium/project-list.php");
		driver.findElement(By.id("btnNewWindow")).click();
		assertEquals ("Projets",driver.getTitle());
		Set<String> set = driver.getWindowHandles();
		assertEquals(2,set.size());
		driver.switchTo().window("toto");
		assertEquals ("My Window",driver.getTitle());
		System.out.print("Handle: " + driver.getWindowHandle());
	}
	// Utiliser la classe action
	@Test
	public void testActions() throws Exception {
		driver.manage().window().maximize();
		Actions builder = new Actions(driver);
		Action mouseOverClothes = builder.moveToElement(driver.findElement(By.cssSelector("#category-3 > a"))).build();
		mouseOverClothes.perform();
		assertTrue(driver.findElement(By.xpath("//*[@id='category-4']/a")).isDisplayed());

	} 
	@AfterEach
	public void tearDown() throws Exception {
//		driver.quit();

		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {


				alert.accept();

			} else {

				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}
}
